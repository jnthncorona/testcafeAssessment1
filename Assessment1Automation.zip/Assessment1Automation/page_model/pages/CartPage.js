import { Selector } from 'testcafe'
class CartPage{
    constructor(){
        this.titlePageCart = Selector('.subheader')
        this.continueShoppingButton = Selector('.btn_secondary')
        this.checkoutButton = Selector('.btn_action.checkout_button')
        this.removeButton = Selector('btn_secondary cart_button')
        this.cartQty = Selector('cart_quantity')
        this.secondItem = Selector('.inventory_item_name')
        this.itemtwo = Selector('#item_0_title_link > div:nth-child(1)')
        this.itemThree = Selector('#item_1_title_link > div')
        this.itemFour = Selector('#item_5_title_link > div')
        this.itemFive = Selector('#item_2_title_link > div')
    }
}

export default new CartPage()