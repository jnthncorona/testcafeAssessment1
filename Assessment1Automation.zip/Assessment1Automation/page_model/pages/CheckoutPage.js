import { Selector } from 'testcafe';
class CheckoutPage{
    constructor(){
        this.firstNameField = Selector('#first-name')
        this.lastNameField = Selector('#last-name')
        this.zipcodeField = Selector('#postal-code')
        this.continueButton = Selector('.btn_primary.cart_button')
        this.fistnameErrorMassage = Selector('.checkout_info_wrapper > form:nth-child(1) > h3')
    }
}

export default new CheckoutPage()