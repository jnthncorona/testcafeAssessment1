import { Selector } from 'testcafe'
class FinishPage {
    constructor(){
        this.orderMessage = Selector('.complete-header')
    }
}

export default new FinishPage()