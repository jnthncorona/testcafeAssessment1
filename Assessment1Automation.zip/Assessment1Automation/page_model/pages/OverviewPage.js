import { Selector } from 'testcafe'
class OverviewPage{
    constructor(){
        this.overViewTitle = Selector ('.subheader')
        this.finishButton = Selector('.btn_action')
        this.cancelButton = Selector('.cart_cancel_link')
        this.secondItem = Selector('.inventory_item_name')
    }
}

export default new OverviewPage()