import { Selector } from 'testcafe'
class ProductPage{
    constructor(){
        this.titlePage = Selector('.product_label')
        this.burgetMenu = Selector('#react-burger-menu-btn')
        this.logoutButton = Selector('#logout_sidebar_link')
        this.shoppingContainer = Selector('.shopping_cart_link.fa-layers.fa-fw')
        this.firstAddButton = Selector('div.inventory_item:nth-child(1) > div:nth-child(3) > button')
        this.secondProductButton = Selector('div.inventory_item:nth-child(2) > div:nth-child(3) > button')
        this.thirdProductButton = Selector('div.inventory_item:nth-child(3) > div:nth-child(3) > button')
        this.fourProductButton = Selector('div.inventory_item:nth-child(4) > div:nth-child(3) > button')
        this.fiftProductButton = Selector('div.inventory_item:nth-child(5) > div:nth-child(3) > button')
        this.shoppingCnt = Selector('.fa-layers-counter.shopping_cart_badge')
    }
}

export default new ProductPage()