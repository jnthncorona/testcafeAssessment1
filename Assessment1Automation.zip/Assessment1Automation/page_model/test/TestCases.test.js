import LoginPage from '../pages/LoginPage'
import ProductPage from '../pages/ProductPage'
import CartPage from '../pages/CartPage'
import CheckoutPage from '../pages/CheckoutPage'
import OverviewPage from '../pages/OverviewPage'
import FinishPage from '../pages/FinishPage'

fixture ('Login feature testing')
.page `https://www.saucedemo.com/`



test('Login with valid user', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)

    await t.expect(ProductPage.titlePage.exists).ok()
})

test('Login with an invalid user', async t => {
    await t
        .typeText(LoginPage.usernameField, 'Invalid_user')
        .typeText(LoginPage.passwordField, 'secret_sauce_wronpassword')
        .click(LoginPage.loginButton)

    await t.expect(LoginPage.errorMessage.exists).ok()
    await t.expect(LoginPage.errorMessage.innerText).eql('')
})

test('Logout from Product Page', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.burgetMenu)
        .click(ProductPage.logoutButton)

    await t.expect(LoginPage.usernameTitle.exists).ok()
})

test ('Login to Product Page', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.shoppingContainer)

    await t.expect(CartPage.titlePageCart.exists).ok()
})

test ('Add a single item to the shopping cart', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.firstAddButton)

    await t.expect(ProductPage.shoppingCnt.exists).ok()
})

test ('Add a multiple items to the shopping cart', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.secondProductButton)
        .click(ProductPage.thirdProductButton)
        .click(ProductPage.fourProductButton)
        .click(ProductPage.fiftProductButton)
        .click(ProductPage.shoppingContainer)

    await t.expect(CartPage.itemtwo.exists).ok()
    await t.expect(CartPage.itemThree.exists).ok()
    await t.expect(CartPage.itemFour.exists).ok()
    await t.expect(CartPage.itemFive.exists).ok()



})

test ('Continue with missing mail information', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.firstAddButton)
        .click(ProductPage.shoppingContainer)
        .click(CartPage.checkoutButton)
        .click(CheckoutPage.continueButton)

    await t.expect(CheckoutPage.fistnameErrorMassage.innerText).eql('Error: First Name is required')
})

test ('Fill user s information ', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.firstAddButton)
        .click(ProductPage.shoppingContainer)
        .click(CartPage.checkoutButton)
        .typeText(CheckoutPage.firstNameField, 'Jonathan')
        .typeText(CheckoutPage.lastNameField, 'Corona')
        .typeText(CheckoutPage.zipcodeField, '45417')
        .click(CheckoutPage.continueButton)

    await t.expect(OverviewPage.overViewTitle.exists).ok()
})

test ('Final Order items ', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.secondProductButton)
        .click(ProductPage.shoppingContainer)
        .click(CartPage.checkoutButton)
        .typeText(CheckoutPage.firstNameField, 'Jonathan')
        .typeText(CheckoutPage.lastNameField, 'Corona')
        .typeText(CheckoutPage.zipcodeField, '45417')
        .click(CheckoutPage.continueButton)
    
    await t.expect(CartPage.secondItem.exists).ok()
    await t.expect(OverviewPage.secondItem.innerText).eql('Sauce Labs Bike Light')
})

test ('Final Order items ', async t => {
    await t
        .typeText(LoginPage.usernameField, 'standard_user')
        .typeText(LoginPage.passwordField, 'secret_sauce')
        .click(LoginPage.loginButton)
        .click(ProductPage.secondProductButton)
        .click(ProductPage.shoppingContainer)
        .click(CartPage.checkoutButton)
        .typeText(CheckoutPage.firstNameField, 'Jonathan')
        .typeText(CheckoutPage.lastNameField, 'Corona')
        .typeText(CheckoutPage.zipcodeField, '45417')
        .click(CheckoutPage.continueButton)
        .click(OverviewPage.finishButton)
    
    await t.expect(FinishPage.orderMessage.exists).ok()
})